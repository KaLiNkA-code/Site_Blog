from django.apps import AppConfig


class EverythingbeatsConfig(AppConfig):
    name = 'everythingbeats'
